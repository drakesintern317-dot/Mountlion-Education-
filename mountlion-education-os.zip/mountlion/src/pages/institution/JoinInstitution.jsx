import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ownerInstitutionsMock } from '../../data/mock.js'
import { useApp } from '../../context/AppContext.jsx'

export default function JoinInstitution() {
  const navigate = useNavigate()
  const { createAccount, createInstitution } = useApp()
  const [query, setQuery] = useState('')
  const [joined, setJoined] = useState(null)
  const institutions = ownerInstitutionsMock().filter(i => i.name.toLowerCase().includes(query.toLowerCase()))

  function join(inst) {
    setJoined(inst)
  }

  function confirm() {
    createAccount({ name: 'Daniel Mwangi', userType: 'general' })
    createInstitution({ name: joined.name, type: 'high' })
    navigate('/dashboard')
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-16 md:py-24">
      <p className="text-xs font-semibold uppercase tracking-wide text-teal">Join institution</p>
      <h1 className="mt-2 text-3xl font-extrabold text-navy">Find your institution</h1>

      <input
        value={query}
        onChange={e => setQuery(e.target.value)}
        placeholder="Search by institution name"
        className="focus-ring mt-6 w-full rounded-xl border border-line px-4 py-2.5 text-sm text-navy placeholder:text-muted"
      />

      <ul className="mt-4 divide-y divide-line rounded-xl2 border border-line bg-white">
        {institutions.map(i => (
          <li key={i.id} className="flex items-center justify-between px-5 py-4">
            <div>
              <p className="font-medium text-navy">{i.name}</p>
              <p className="text-xs text-muted">{i.type} · {i.users.toLocaleString()} members</p>
            </div>
            <button onClick={() => join(i)} className="focus-ring rounded-full border border-line px-4 py-1.5 text-sm font-semibold text-royal hover:border-royal/40">
              Request to join
            </button>
          </li>
        ))}
        {institutions.length === 0 && <li className="px-5 py-6 text-center text-sm text-muted">No institutions match "{query}"</li>}
      </ul>

      {joined && (
        <div className="mt-6 rounded-xl2 border border-teal/30 bg-teal/5 p-5">
          <p className="text-sm text-navy">Request sent to <strong>{joined.name}</strong>. For this demo, you can preview the workspace right away.</p>
          <button onClick={confirm} className="focus-ring mt-3 rounded-full bg-teal px-5 py-2 text-sm font-semibold text-white hover:bg-[#0b8580]">
            Preview Workspace
          </button>
        </div>
      )}
    </div>
  )
}
