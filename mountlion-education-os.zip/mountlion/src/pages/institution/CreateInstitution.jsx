import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { INSTITUTION_TYPES } from '../../data/reference.js'

export default function CreateInstitution() {
  const navigate = useNavigate()
  const [selected, setSelected] = useState(null)

  function proceed() {
    if (!selected) return
    sessionStorage.setItem('mountlion_pending_institution_type', selected)
    navigate('/create-institution/details')
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-16 md:py-24">
      <p className="text-xs font-semibold uppercase tracking-wide text-teal">Create institution — step 1 of 3</p>
      <h1 className="mt-2 text-3xl font-extrabold text-navy">What type of institution is this?</h1>
      <p className="mt-2 text-sm text-body">This decides your dashboard layout, terminology, and available services.</p>

      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        {INSTITUTION_TYPES.map(t => (
          <button
            key={t.id}
            onClick={() => setSelected(t.id)}
            className={`focus-ring rounded-xl2 border p-5 text-left transition-colors ${selected === t.id ? 'border-royal bg-royal/5' : 'border-line bg-white hover:border-royal/40'}`}
          >
            <span className="block font-bold text-navy">{t.label}</span>
            <span className="mt-0.5 block text-sm text-muted">{t.unit} · {t.stat}</span>
          </button>
        ))}
      </div>

      <button
        onClick={proceed}
        disabled={!selected}
        className="focus-ring mt-8 inline-flex items-center justify-center rounded-full bg-royal px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1150cf] disabled:opacity-40"
      >
        Continue
      </button>
    </div>
  )
}
