import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { INSTITUTION_TYPES, COUNTRIES } from '../../data/reference.js'
import { useApp } from '../../context/AppContext.jsx'

export default function InstitutionDetails() {
  const navigate = useNavigate()
  const { createInstitution, setCountry } = useApp()
  const typeId = sessionStorage.getItem('mountlion_pending_institution_type') || 'high'
  const type = INSTITUTION_TYPES.find(t => t.id === typeId)
  const [name, setName] = useState('')
  const [countryCode, setCountryCode] = useState('KE')

  function handleSubmit(e) {
    e.preventDefault()
    const country = COUNTRIES.find(c => c.code === countryCode)
    if (country) setCountry(country)
    createInstitution({ name: name || `${type.label} Demo`, type: typeId })
    navigate('/dashboard')
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16 md:py-24">
      <p className="text-xs font-semibold uppercase tracking-wide text-teal">Create institution — step 2 of 3</p>
      <h1 className="mt-2 text-3xl font-extrabold text-navy">Set up your {type.label.toLowerCase()}</h1>
      <p className="mt-2 text-sm text-body">This creates your workspace and institution dashboard.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-navy">Institution name</span>
          <input
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder={`e.g. Kericho ${type.label}`}
            className="focus-ring w-full rounded-xl border border-line px-4 py-2.5 text-sm text-navy placeholder:text-muted"
          />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-navy">Country</span>
          <select
            value={countryCode}
            onChange={e => setCountryCode(e.target.value)}
            className="focus-ring w-full rounded-xl border border-line bg-white px-4 py-2.5 text-sm text-navy"
          >
            {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name}</option>)}
          </select>
        </label>
        <button type="submit" className="focus-ring w-full rounded-full bg-royal px-6 py-2.5 text-sm font-semibold text-white hover:bg-[#1150cf]">
          Create Workspace
        </button>
      </form>
    </div>
  )
}
