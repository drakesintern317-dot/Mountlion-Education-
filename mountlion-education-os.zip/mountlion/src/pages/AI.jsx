import React, { useState } from 'react'
import { AI_PROMPTS, aiRespond } from '../data/mock.js'

export default function AI() {
  const [messages, setMessages] = useState([])
  const [draft, setDraft] = useState('')
  const [loading, setLoading] = useState(false)

  function ask(prompt) {
    if (!prompt.trim()) return
    setMessages(m => [...m, { from: 'me', text: prompt }])
    setDraft('')
    setLoading(true)
    setTimeout(() => {
      setMessages(m => [...m, { from: 'ai', text: aiRespond(prompt) }])
      setLoading(false)
    }, 1100)
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 md:px-8">
      <div className="flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-2xl bg-teal/10 text-teal">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 2l1.8 4.6L18 8l-4.2 1.4L12 14l-1.8-4.6L6 8l4.2-1.4L12 2z" fill="currentColor"/></svg>
        </span>
        <div>
          <h1 className="text-xl font-extrabold text-navy">Ask Mountlion AI</h1>
          <p className="text-xs text-muted">Answers use your institution's live data.</p>
        </div>
      </div>

      {messages.length === 0 ? (
        <div className="mt-8">
          <p className="text-sm font-semibold text-navy">Try asking:</p>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {AI_PROMPTS.map(p => (
              <button key={p} onClick={() => ask(p)} className="focus-ring rounded-xl2 border border-line bg-white p-4 text-left text-sm text-navy transition-colors hover:border-teal/50">
                {p}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="thin-scroll mt-8 max-h-[55vh] space-y-4 overflow-y-auto">
          {messages.map((m, idx) => (
            <div key={idx} className={`flex ${m.from === 'me' ? 'justify-end' : 'justify-start'}`}>
              <p className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${m.from === 'me' ? 'bg-royal text-white' : 'border border-teal/20 bg-teal/5 text-navy'}`}>{m.text}</p>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <p className="flex items-center gap-1.5 rounded-2xl border border-teal/20 bg-teal/5 px-4 py-3 text-sm text-teal">
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-teal [animation-delay:-0.2s]" />
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-teal" />
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-teal [animation-delay:0.2s]" />
              </p>
            </div>
          )}
        </div>
      )}

      <form onSubmit={e => { e.preventDefault(); ask(draft) }} className="mt-8 flex items-center gap-2">
        <input
          value={draft}
          onChange={e => setDraft(e.target.value)}
          placeholder="Ask Mountlion AI anything about your institution..."
          className="focus-ring flex-1 rounded-full border border-line px-4 py-3 text-sm placeholder:text-muted"
        />
        <button type="submit" className="focus-ring grid h-11 w-11 shrink-0 place-items-center rounded-full bg-teal text-white hover:bg-[#0b8580]">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M4 12l16-8-6 16-2-7-8-1z" fill="white"/></svg>
        </button>
      </form>
    </div>
  )
}
