import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import Button from '../components/Button.jsx'
import { ownerInstitutionsMock } from '../data/mock.js'
import { INSTITUTION_TYPES } from '../data/reference.js'

export default function Institutions() {
  const [filter, setFilter] = useState('all')
  const institutions = ownerInstitutionsMock()
  const filtered = filter === 'all' ? institutions : institutions.filter(i => i.type === filter)

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 md:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-teal">Institutions</p>
          <h1 className="mt-2 text-3xl font-extrabold text-navy md:text-4xl">Explore institutions on Mountlion.</h1>
        </div>
        <div className="flex gap-3">
          <Button to="/create-institution" variant="primary">Create Institution</Button>
          <Button to="/institutions/join" variant="secondary">Join Institution</Button>
        </div>
      </div>

      <div className="mt-8 flex flex-wrap gap-2">
        <button onClick={() => setFilter('all')} className={`focus-ring rounded-full px-4 py-1.5 text-sm font-medium ${filter === 'all' ? 'bg-navy text-white' : 'border border-line text-navy'}`}>All types</button>
        {INSTITUTION_TYPES.map(t => (
          <button key={t.id} onClick={() => setFilter(t.label)} className={`focus-ring rounded-full px-4 py-1.5 text-sm font-medium ${filter === t.label ? 'bg-navy text-white' : 'border border-line text-navy'}`}>{t.label}</button>
        ))}
      </div>

      <div className="mt-8 divide-y divide-line border-y border-line">
        {filtered.map(i => (
          <div key={i.id} className="grid items-center gap-2 py-5 md:grid-cols-[1.5fr_1fr_1fr_auto]">
            <div>
              <p className="font-bold text-navy">{i.name}</p>
              <p className="text-xs text-muted">{i.type}</p>
            </div>
            <p className="text-sm text-body">{i.users.toLocaleString()} members</p>
            <span className={`w-fit rounded-full px-2.5 py-1 text-xs font-medium ${i.status === 'Active' ? 'bg-teal/10 text-teal' : 'bg-royal/10 text-royal'}`}>{i.status}</span>
            <Link to="/institutions/join" className="focus-ring text-sm font-semibold text-royal hover:underline">Request to join →</Link>
          </div>
        ))}
      </div>
    </div>
  )
}
