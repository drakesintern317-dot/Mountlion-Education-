import React from 'react'
import Button from '../components/Button.jsx'

export default function NotFound() {
  return (
    <div className="mx-auto max-w-md px-4 py-24 text-center">
      <p className="font-mono text-sm text-muted">404</p>
      <h1 className="mt-2 text-2xl font-extrabold text-navy">Page not found</h1>
      <p className="mt-2 text-sm text-body">This part of Mountlion doesn't exist yet.</p>
      <Button to="/" className="mt-6">Back home</Button>
    </div>
  )
}
