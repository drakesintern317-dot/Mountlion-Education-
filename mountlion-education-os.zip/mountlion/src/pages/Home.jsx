import React from 'react'
import { Link } from 'react-router-dom'
import Button from '../components/Button.jsx'
import LivePreviewPanel from '../components/LivePreviewPanel.jsx'
import { SERVICE_CATEGORIES, COUNTRIES, INSTITUTION_TYPES } from '../data/reference.js'

export default function Home() {
  return (
    <div>
      {/* HERO */}
      <section className="mx-auto max-w-7xl px-4 pt-14 pb-20 md:px-8 md:pt-20">
        <div className="grid items-center gap-14 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full bg-royal/10 px-3 py-1 text-xs font-semibold text-royal">
              Mountlion Education OS™
            </p>
            <h1 className="mt-5 text-[2.5rem] leading-[1.08] font-extrabold tracking-tight text-navy md:text-[3.4rem]">
              One intelligent platform for <span className="text-royal">education</span>, institutions, and every <span className="text-teal">student</span> in between.
            </h1>
            <p className="mt-6 max-w-lg text-lg text-body">
              From a single primary school to a national university system — Mountlion connects people, institutions, and government education services in one place.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button to="/get-started" variant="primary">Get Started</Button>
              <Button to="/services" variant="secondary">Explore Services</Button>
            </div>
            <div className="mt-10 flex items-center gap-6 text-xs text-muted">
              <span>Trusted structure for</span>
              <span className="font-semibold text-navy">Schools</span>
              <span className="h-1 w-1 rounded-full bg-line" />
              <span className="font-semibold text-navy">Colleges</span>
              <span className="h-1 w-1 rounded-full bg-line" />
              <span className="font-semibold text-navy">Universities</span>
              <span className="h-1 w-1 rounded-full bg-line" />
              <span className="font-semibold text-navy">Government</span>
            </div>
          </div>
          <LivePreviewPanel />
        </div>
      </section>

      {/* SERVICES — horizontal storytelling, not a grid */}
      <section className="border-t border-line bg-white py-20">
        <div className="mx-auto max-w-7xl px-4 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-teal">What you can do on Mountlion</p>
              <h2 className="mt-2 text-3xl font-extrabold text-navy md:text-4xl">A single home for every education service.</h2>
            </div>
            <Link to="/services" className="focus-ring text-sm font-semibold text-royal hover:underline">View all services →</Link>
          </div>

          <div className="mt-14 divide-y divide-line border-y border-line">
            {SERVICE_CATEGORIES.slice(0, 5).map((s, i) => (
              <div key={s.id} className="grid gap-4 py-8 md:grid-cols-[80px_1fr_1.2fr] md:items-center">
                <span className="font-mono text-sm text-muted">0{i + 1}</span>
                <div>
                  <h3 className="text-xl font-bold text-navy">{s.label}</h3>
                  <p className="mt-1 text-sm text-body">{s.blurb}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {s.featured.map(f => (
                    <span key={f} className="rounded-full border border-line px-3 py-1 text-xs text-body">{f}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INSTITUTIONS CTA — asymmetric, not boxed */}
      <section className="border-t border-line bg-navy py-20">
        <div className="mx-auto grid max-w-7xl gap-12 px-4 md:px-8 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-teal">For institutions</p>
            <h2 className="mt-2 text-3xl font-extrabold text-white md:text-4xl">Every institution type, one operating system.</h2>
            <p className="mt-4 max-w-md text-white/70">
              Set up a workspace in minutes. Your dashboard, terminology, and services adapt automatically to your institution type.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button to="/create-institution" variant="teal">Create Institution</Button>
              <Button to="/institutions/join" variant="secondary" className="!bg-transparent !text-white !border-white/25 hover:!border-white/50">Join Institution</Button>
            </div>
          </div>
          <div className="flex flex-wrap gap-2.5">
            {INSTITUTION_TYPES.map(t => (
              <span key={t.id} className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-sm text-white/85">{t.label}</span>
            ))}
          </div>
        </div>
      </section>

      {/* GLOBAL STRIP */}
      <section className="border-t border-line bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 md:px-8">
          <p className="text-xs font-semibold uppercase tracking-wide text-teal">Built for a global education system</p>
          <h2 className="mt-2 max-w-2xl text-2xl font-extrabold text-navy md:text-3xl">Mountlion adapts to your country's curriculum, currency, and government services.</h2>
          <div className="mt-8 flex flex-wrap gap-3">
            {COUNTRIES.map(c => (
              <span key={c.code} className="rounded-full border border-line px-4 py-2 text-sm text-body">{c.name}</span>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
