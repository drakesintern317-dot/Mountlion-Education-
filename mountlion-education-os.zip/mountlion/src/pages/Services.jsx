import React, { useState } from 'react'
import { SERVICE_CATEGORIES } from '../data/reference.js'

export default function Services() {
  const [active, setActive] = useState('education')
  const [query, setQuery] = useState('')
  const current = SERVICE_CATEGORIES.find(c => c.id === active)
  const filteredFeatured = current.featured.filter(f => f.toLowerCase().includes(query.toLowerCase()))

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 md:px-8">
      <p className="text-xs font-semibold uppercase tracking-wide text-teal">Services</p>
      <h1 className="mt-2 text-3xl font-extrabold text-navy md:text-4xl">Every education service, in one place.</h1>

      <div className="mt-6 flex items-center gap-2 rounded-full border border-line bg-white px-4 py-2.5 md:max-w-md">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="text-muted shrink-0"><circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.8"/><path d="M21 21l-3.5-3.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search services" className="focus-ring w-full bg-transparent text-sm placeholder:text-muted" />
      </div>

      <div className="mt-8 flex gap-2 overflow-x-auto pb-2">
        {SERVICE_CATEGORIES.map(c => (
          <button
            key={c.id}
            onClick={() => setActive(c.id)}
            className={`focus-ring shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${active === c.id ? 'bg-navy text-white' : 'border border-line text-navy hover:border-royal/40'}`}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="mt-8 rounded-xl2 border border-line bg-white p-6 md:p-8">
        <h2 className="text-2xl font-extrabold text-navy">{current.label}</h2>
        <p className="mt-1 text-body">{current.blurb}</p>
        <div className="mt-6 divide-y divide-line border-t border-line">
          {filteredFeatured.map((f, i) => (
            <div key={f} className="flex items-center justify-between py-4">
              <div className="flex items-center gap-4">
                <span className="font-mono text-xs text-muted">0{i + 1}</span>
                <span className="font-medium text-navy">{f}</span>
              </div>
              <button className="focus-ring rounded-full border border-line px-4 py-1.5 text-sm font-semibold text-royal hover:border-royal/40">View</button>
            </div>
          ))}
          {filteredFeatured.length === 0 && <p className="py-6 text-center text-sm text-muted">No services match "{query}" in {current.label}.</p>}
        </div>
      </div>
    </div>
  )
}
