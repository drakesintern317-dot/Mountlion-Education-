import React, { useState } from 'react'
import { conversationsMock } from '../data/mock.js'

export default function Connect() {
  const [conversations, setConversations] = useState(conversationsMock())
  const [activeId, setActiveId] = useState(conversationsMock()[0].id)
  const [query, setQuery] = useState('')
  const [draft, setDraft] = useState('')
  const [showList, setShowList] = useState(true)

  const active = conversations.find(c => c.id === activeId)
  const filtered = conversations.filter(c => c.name.toLowerCase().includes(query.toLowerCase()))

  function send(e) {
    e.preventDefault()
    if (!draft.trim()) return
    setConversations(cs => cs.map(c => c.id === activeId
      ? { ...c, messages: [...c.messages, { from: 'me', text: draft }], preview: draft, unread: 0 }
      : c))
    setDraft('')
  }

  function openConversation(id) {
    setActiveId(id)
    setConversations(cs => cs.map(c => c.id === id ? { ...c, unread: 0 } : c))
    setShowList(false)
  }

  return (
    <div className="mx-auto flex h-[calc(100vh-4rem)] max-w-6xl md:h-[calc(100vh-4rem)]">
      {/* Conversation list */}
      <div className={`w-full shrink-0 border-r border-line md:block md:w-80 ${showList ? 'block' : 'hidden'}`}>
        <div className="border-b border-line p-4">
          <h1 className="text-lg font-extrabold text-navy">Mountlion Connect</h1>
          <div className="mt-3 flex items-center gap-2 rounded-full border border-line px-3 py-2">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" className="text-muted shrink-0"><circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.8"/><path d="M21 21l-3.5-3.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search conversations" className="focus-ring w-full bg-transparent text-sm placeholder:text-muted" />
          </div>
        </div>
        <ul className="thin-scroll overflow-y-auto" style={{maxHeight: 'calc(100% - 96px)'}}>
          {filtered.map(c => (
            <li key={c.id}>
              <button onClick={() => openConversation(c.id)} className={`focus-ring flex w-full items-center gap-3 px-4 py-3.5 text-left hover:bg-canvas ${c.id === activeId ? 'bg-canvas' : ''}`}>
                <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-full text-xs font-bold text-white ${c.group ? 'bg-teal' : 'bg-navy'}`}>{c.name[0]}</span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center justify-between">
                    <span className="truncate text-sm font-medium text-navy">{c.name}</span>
                  </span>
                  <span className="block truncate text-xs text-muted">{c.preview}</span>
                </span>
                {c.unread > 0 && <span className="grid h-5 min-w-5 shrink-0 place-items-center rounded-full bg-royal px-1 text-[10px] font-bold text-white">{c.unread}</span>}
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Active conversation */}
      <div className={`flex min-w-0 flex-1 flex-col ${showList ? 'hidden md:flex' : 'flex'}`}>
        <div className="flex items-center gap-3 border-b border-line px-4 py-3.5">
          <button onClick={() => setShowList(true)} className="focus-ring grid h-8 w-8 place-items-center rounded-full md:hidden">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="#0B1F3A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <span className={`grid h-9 w-9 place-items-center rounded-full text-xs font-bold text-white ${active.group ? 'bg-teal' : 'bg-navy'}`}>{active.name[0]}</span>
          <p className="font-semibold text-navy">{active.name}</p>
        </div>
        <div className="thin-scroll flex-1 space-y-3 overflow-y-auto p-4">
          {active.messages.map((m, idx) => (
            <div key={idx} className={`flex ${m.from === 'me' ? 'justify-end' : 'justify-start'}`}>
              <p className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${m.from === 'me' ? 'bg-royal text-white' : 'bg-canvas text-navy'}`}>{m.text}</p>
            </div>
          ))}
        </div>
        <form onSubmit={send} className="flex items-center gap-2 border-t border-line p-3">
          <input value={draft} onChange={e => setDraft(e.target.value)} placeholder="Message..." className="focus-ring flex-1 rounded-full border border-line px-4 py-2 text-sm placeholder:text-muted" />
          <button type="submit" className="focus-ring grid h-9 w-9 shrink-0 place-items-center rounded-full bg-royal text-white hover:bg-[#1150cf]">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M4 12l16-8-6 16-2-7-8-1z" fill="white"/></svg>
          </button>
        </form>
      </div>
    </div>
  )
}
