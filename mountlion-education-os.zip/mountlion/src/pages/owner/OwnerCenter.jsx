import React, { useState } from 'react'
import { ownerInstitutionsMock, paymentDestinationsMock } from '../../data/mock.js'

const TABS = ['Institutions', 'Users', 'Subscriptions', 'Revenue', 'Payment Destinations', 'Platform Settings', 'Service Integrations', 'Audit Records']

export default function OwnerCenter() {
  const [tab, setTab] = useState('Institutions')

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-8">
      <div className="rounded-xl2 border border-line bg-white p-5">
        <p className="text-xs font-semibold uppercase tracking-wide text-teal">Private — Platform Owner only</p>
        <h1 className="mt-1 text-2xl font-extrabold text-navy">Mountlion Owner Center</h1>
        <div className="mt-3 grid grid-cols-2 gap-x-8 gap-y-1 text-xs text-muted sm:grid-cols-4">
          <p><span className="font-semibold text-navy">Owner:</span> Oscarian Express</p>
          <p><span className="font-semibold text-navy">Product:</span> Mountlion Education OS™</p>
          <p><span className="font-semibold text-navy">Status:</span> Platform Property</p>
          <p><span className="font-semibold text-navy">Copyright:</span> © 2026 Oscarian Express</p>
        </div>
      </div>

      <div className="mt-6 flex gap-2 overflow-x-auto pb-2">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} className={`focus-ring shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${tab === t ? 'bg-navy text-white' : 'border border-line text-navy hover:border-royal/40'}`}>
            {t}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {tab === 'Institutions' && <InstitutionsTab />}
        {tab === 'Payment Destinations' && <PaymentTab />}
        {tab === 'Revenue' && <RevenueTab />}
        {!['Institutions', 'Payment Destinations', 'Revenue'].includes(tab) && (
          <div className="rounded-xl2 border border-line bg-white p-8 text-center text-sm text-muted">
            {tab} is stubbed in this prototype — ready to wire up to real data once a backend is connected.
          </div>
        )}
      </div>
    </div>
  )
}

function InstitutionsTab() {
  const institutions = ownerInstitutionsMock()
  return (
    <div className="overflow-hidden rounded-xl2 border border-line bg-white">
      <div className="hidden grid-cols-[1.5fr_1fr_0.7fr_0.7fr_0.7fr] gap-4 border-b border-line px-5 py-3 text-xs font-semibold uppercase tracking-wide text-muted md:grid">
        <span>Institution</span><span>Type</span><span>Users</span><span>Plan</span><span>Status</span>
      </div>
      <ul className="divide-y divide-line">
        {institutions.map(i => (
          <li key={i.id} className="grid grid-cols-2 gap-2 px-5 py-4 md:grid-cols-[1.5fr_1fr_0.7fr_0.7fr_0.7fr] md:items-center md:gap-4">
            <span className="font-medium text-navy">{i.name}</span>
            <span className="text-sm text-body">{i.type}</span>
            <span className="text-sm text-body">{i.users.toLocaleString()}</span>
            <span className="text-sm text-body">{i.plan}</span>
            <span className={`w-fit rounded-full px-2.5 py-1 text-xs font-medium ${i.status === 'Active' ? 'bg-teal/10 text-teal' : 'bg-royal/10 text-royal'}`}>{i.status}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function RevenueTab() {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <div className="rounded-xl2 border border-line bg-white p-5">
        <p className="font-mono text-2xl font-medium text-navy">KES 84.2M</p>
        <p className="mt-1 text-xs text-muted">Total revenue (trailing 12mo)</p>
      </div>
      <div className="rounded-xl2 border border-line bg-white p-5">
        <p className="font-mono text-2xl font-medium text-teal">+18%</p>
        <p className="mt-1 text-xs text-muted">Growth vs. previous period</p>
      </div>
      <div className="rounded-xl2 border border-line bg-white p-5">
        <p className="font-mono text-2xl font-medium text-royal">312</p>
        <p className="mt-1 text-xs text-muted">Paying institutions</p>
      </div>
    </div>
  )
}

function PaymentTab() {
  const [destinations, setDestinations] = useState(paymentDestinationsMock())

  function setActive(id) {
    setDestinations(ds => ds.map(d => ({ ...d, active: d.id === id })))
  }
  function toggleEnabled(id) {
    setDestinations(ds => ds.map(d => d.id === id ? { ...d, disabled: !d.disabled } : d))
  }

  return (
    <div>
      <p className="text-sm text-muted">Payment credentials are never stored in frontend code — this manages which destination is active, not the credentials themselves.</p>
      <ul className="mt-4 divide-y divide-line rounded-xl2 border border-line bg-white">
        {destinations.map(d => (
          <li key={d.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
            <div>
              <p className="font-medium text-navy">{d.type}</p>
              <p className="text-xs text-muted">{d.label}</p>
            </div>
            <div className="flex items-center gap-2">
              {d.active ? (
                <span className="rounded-full bg-teal/10 px-3 py-1 text-xs font-semibold text-teal">Active destination</span>
              ) : (
                <button onClick={() => setActive(d.id)} className="focus-ring rounded-full border border-line px-3 py-1.5 text-xs font-semibold text-royal hover:border-royal/40">
                  Make active
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
      <button className="focus-ring mt-4 rounded-full border border-line px-5 py-2 text-sm font-semibold text-navy hover:border-royal/40">+ Add payment destination</button>
    </div>
  )
}
