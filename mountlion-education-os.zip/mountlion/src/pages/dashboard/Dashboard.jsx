import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../../context/AppContext.jsx'
import { statsForInstitution, tasksForUser, activityMock } from '../../data/mock.js'
import { INSTITUTION_TYPES, USER_TYPES } from '../../data/reference.js'

export default function Dashboard() {
  const { user, institution, demoMode } = useApp()
  const navigate = useNavigate()

  const institutionType = institution?.type || (['owner','public'].includes(demoMode) ? null : demoMode)
  const isPreview = !user && !institution

  if (demoMode === 'owner' && !institutionType) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <p className="text-xs font-semibold uppercase tracking-wide text-teal">Platform Owner demo</p>
        <h1 className="mt-2 text-2xl font-extrabold text-navy">You're viewing the Owner demo</h1>
        <p className="mt-2 text-sm text-body">The Owner Center is a separate, private section of Mountlion.</p>
        <button onClick={() => navigate('/owner')} className="focus-ring mt-6 rounded-full bg-royal px-6 py-2.5 text-sm font-semibold text-white hover:bg-[#1150cf]">
          Open Owner Center
        </button>
      </div>
    )
  }

  if (institutionType) {
    return <InstitutionDashboard institutionType={institutionType} institutionName={institution?.name} isPreview={isPreview} />
  }

  if (user) {
    return <PersonalDashboard />
  }

  return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <p className="text-xs font-semibold uppercase tracking-wide text-teal">No account yet</p>
      <h1 className="mt-2 text-2xl font-extrabold text-navy">Your dashboard lives here once you're in.</h1>
      <p className="mt-2 text-sm text-body">Create an account, or switch the demo selector above to preview an institution dashboard.</p>
      <Link to="/get-started" className="focus-ring mt-6 inline-block rounded-full bg-royal px-6 py-2.5 text-sm font-semibold text-white hover:bg-[#1150cf]">
        Get Started
      </Link>
    </div>
  )
}

function PersonalDashboard() {
  const { user } = useApp()
  const [tasks, setTasks] = useState(tasksForUser(user.userType))
  const activity = activityMock()
  const label = USER_TYPES.find(t => t.id === user.userType)?.label || 'User'

  function toggleTask(id) {
    setTasks(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t))
  }
  const pending = tasks.filter(t => !t.done).length

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-8">
      <Header title={`Good to see you, ${user.name.split(' ')[0]}`} subtitle={`${label} · you have ${pending} item${pending !== 1 ? 's' : ''} needing attention today.`} />
      <div className="mt-8 grid gap-6 lg:grid-cols-[1.3fr_1fr]">
        <div className="space-y-6">
          <Panel title="Your tasks">
            <ul className="divide-y divide-line">
              {tasks.map(t => (
                <li key={t.id} className="flex items-center gap-3 py-3">
                  <button
                    onClick={() => toggleTask(t.id)}
                    aria-label={t.done ? 'Mark as not done' : 'Mark as done'}
                    className={`focus-ring grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 ${t.done ? 'border-teal bg-teal' : 'border-line'}`}
                  >
                    {t.done && <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M5 12l5 5L20 7" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                  </button>
                  <span className={`text-sm ${t.done ? 'text-muted line-through' : 'text-navy'}`}>{t.title}</span>
                </li>
              ))}
            </ul>
          </Panel>
          <Panel title="Recent activity">
            <ul className="space-y-3">
              {activity.map(a => (
                <li key={a.id} className="flex items-center justify-between text-sm">
                  <span className="text-navy">{a.text}</span>
                  <span className="shrink-0 pl-3 text-xs text-muted">{a.time}</span>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
        <div className="space-y-6">
          <AIPanel />
          <Panel title="Quick links">
            <div className="flex flex-col gap-2">
              <Link to="/connect" className="focus-ring rounded-xl border border-line px-4 py-3 text-sm font-medium text-navy hover:border-royal/40">Open Mountlion Connect</Link>
              <Link to="/services" className="focus-ring rounded-xl border border-line px-4 py-3 text-sm font-medium text-navy hover:border-royal/40">Browse Services</Link>
              <Link to="/settings" className="focus-ring rounded-xl border border-line px-4 py-3 text-sm font-medium text-navy hover:border-royal/40">Account Settings</Link>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  )
}

function InstitutionDashboard({ institutionType, institutionName, isPreview }) {
  const stats = statsForInstitution(institutionType)
  const meta = INSTITUTION_TYPES.find(t => t.id === institutionType)
  const activity = activityMock()
  const [search, setSearch] = useState('')
  const [tab, setTab] = useState('overview')

  const roster = [
    { name: 'Grace Wanjiru', role: meta?.unit.slice(0, -1) || 'Student', status: 'Active' },
    { name: 'David Otieno', role: 'Teacher', status: 'Active' },
    { name: 'Amina Yusuf', role: meta?.unit.slice(0, -1) || 'Student', status: 'On leave' },
    { name: 'Peter Kamau', role: 'Teacher', status: 'Active' },
  ].filter(r => r.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-8">
      {isPreview && (
        <div className="mb-6 rounded-xl2 border border-teal/30 bg-teal/5 px-4 py-3 text-sm text-navy">
          You're previewing a sample <strong>{meta?.label}</strong> dashboard. Create an institution to make this yours.
        </div>
      )}
      <Header title={institutionName || `${meta?.label} Demo`} subtitle={`${meta?.label} · ${stats.attendance}% attendance this week`} />

      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label={stats.label} value={stats.people.toLocaleString()} />
        <Stat label="Staff" value={stats.staff} />
        <Stat label="Attendance" value={`${stats.attendance}%`} accent="teal" />
        <Stat label="Revenue (term)" value={stats.revenue} accent="royal" />
      </div>

      <div className="mt-8 flex gap-1 border-b border-line">
        {['overview', 'people', 'reports'].map(t => (
          <button key={t} onClick={() => setTab(t)} className={`focus-ring -mb-px border-b-2 px-4 py-2.5 text-sm font-semibold capitalize ${tab === t ? 'border-royal text-royal' : 'border-transparent text-muted hover:text-navy'}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="mt-6 grid gap-6 lg:grid-cols-[1.3fr_1fr]">
          <Panel title="Recent activity">
            <ul className="space-y-3">
              {activity.map(a => (
                <li key={a.id} className="flex items-center justify-between text-sm">
                  <span className="text-navy">{a.text}</span>
                  <span className="shrink-0 pl-3 text-xs text-muted">{a.time}</span>
                </li>
              ))}
            </ul>
          </Panel>
          <AIPanel />
        </div>
      )}

      {tab === 'people' && (
        <div className="mt-6">
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={`Search ${meta?.unit.toLowerCase()} or staff`}
            className="focus-ring w-full max-w-sm rounded-xl border border-line px-4 py-2.5 text-sm placeholder:text-muted"
          />
          <div className="mt-4 overflow-hidden rounded-xl2 border border-line">
            <ul className="divide-y divide-line">
              {roster.map(r => (
                <li key={r.name} className="flex items-center justify-between px-5 py-3.5">
                  <div className="flex items-center gap-3">
                    <span className="grid h-9 w-9 place-items-center rounded-full bg-navy/5 text-xs font-bold text-navy">{r.name[0]}</span>
                    <div>
                      <p className="text-sm font-medium text-navy">{r.name}</p>
                      <p className="text-xs text-muted">{r.role}</p>
                    </div>
                  </div>
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${r.status === 'Active' ? 'bg-teal/10 text-teal' : 'bg-navy/5 text-muted'}`}>{r.status}</span>
                </li>
              ))}
              {roster.length === 0 && <li className="px-5 py-6 text-center text-sm text-muted">No matches for "{search}"</li>}
            </ul>
          </div>
        </div>
      )}

      {tab === 'reports' && (
        <Panel title="Term performance" className="mt-6">
          <p className="text-sm text-body">Overall attendance is at {stats.attendance}%, with {stats.people.toLocaleString()} {stats.label.toLowerCase()} enrolled and {stats.staff} staff across the institution.</p>
          <div className="mt-4 h-32 rounded-xl bg-gradient-to-r from-royal/10 via-teal/10 to-transparent" />
        </Panel>
      )}
    </div>
  )
}

function AIPanel() {
  return (
    <div className="rounded-xl2 border border-line bg-white p-5 shadow-panel">
      <div className="flex items-center gap-2">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="text-teal"><path d="M12 2l1.8 4.6L18 8l-4.2 1.4L12 14l-1.8-4.6L6 8l4.2-1.4L12 2z" fill="currentColor"/></svg>
        <p className="text-sm font-semibold text-navy">Mountlion AI</p>
      </div>
      <p className="mt-2 text-sm text-body">"You have 5 items requiring attention today, including 2 fee approvals and 1 unread message."</p>
      <Link to="/ai" className="focus-ring mt-3 inline-block text-sm font-semibold text-royal hover:underline">Ask Mountlion AI →</Link>
    </div>
  )
}

function Header({ title, subtitle }) {
  return (
    <div>
      <h1 className="text-2xl font-extrabold text-navy md:text-3xl">{title}</h1>
      <p className="mt-1 text-sm text-body">{subtitle}</p>
    </div>
  )
}

function Panel({ title, children, className = '' }) {
  return (
    <div className={`rounded-xl2 border border-line bg-white p-5 shadow-panel ${className}`}>
      <p className="mb-3 text-sm font-semibold text-navy">{title}</p>
      {children}
    </div>
  )
}

function Stat({ label, value, accent }) {
  const color = accent === 'teal' ? 'text-teal' : accent === 'royal' ? 'text-royal' : 'text-navy'
  return (
    <div className="rounded-xl2 border border-line bg-white p-4">
      <p className={`font-mono text-xl font-medium tabular-nums ${color}`}>{value}</p>
      <p className="mt-1 text-xs text-muted">{label}</p>
    </div>
  )
}
