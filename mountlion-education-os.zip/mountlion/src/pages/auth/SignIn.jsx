import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Button from '../../components/Button.jsx'
import { useApp } from '../../context/AppContext.jsx'

export default function SignIn() {
  const { createAccount } = useApp()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    // Mock auth: any credentials sign in as a returning student for the demo
    createAccount({ name: email.split('@')[0] || 'Daniel', userType: 'student' })
    navigate('/dashboard')
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16 md:py-24">
      <p className="text-xs font-semibold uppercase tracking-wide text-teal">Welcome back</p>
      <h1 className="mt-2 text-3xl font-extrabold text-navy">Sign in to Mountlion</h1>
      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <Field label="Email address" type="email" value={email} onChange={setEmail} placeholder="you@example.com" required />
        <Field label="Password" type="password" value={password} onChange={setPassword} placeholder="••••••••" required />
        <Button type="submit" className="w-full">Sign In</Button>
      </form>
      <p className="mt-6 text-center text-sm text-muted">
        New to Mountlion? <a href="/get-started" onClick={(e)=>{e.preventDefault(); navigate('/get-started')}} className="font-semibold text-royal hover:underline">Create an account</a>
      </p>
    </div>
  )
}

function Field({ label, type = 'text', value, onChange, placeholder, required }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-navy">{label}</span>
      <input
        type={type}
        required={required}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="focus-ring w-full rounded-xl border border-line px-4 py-2.5 text-sm text-navy placeholder:text-muted"
      />
    </label>
  )
}
