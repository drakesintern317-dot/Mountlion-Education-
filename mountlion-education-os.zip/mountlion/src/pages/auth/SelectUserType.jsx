import React from 'react'
import { useNavigate } from 'react-router-dom'
import { USER_TYPES } from '../../data/reference.js'
import { useApp } from '../../context/AppContext.jsx'
import { Steps } from './CreateAccount.jsx'

export default function SelectUserType() {
  const navigate = useNavigate()
  const { createAccount } = useApp()

  function choose(userType) {
    const name = sessionStorage.getItem('mountlion_pending_name') || 'Daniel Mwangi'
    createAccount({ name, userType })
    navigate('/dashboard')
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-16 md:py-24">
      <Steps current={2} />
      <p className="mt-6 text-xs font-semibold uppercase tracking-wide text-teal">Step 2 of 2</p>
      <h1 className="mt-2 text-3xl font-extrabold text-navy">Who are you on Mountlion?</h1>
      <p className="mt-2 text-sm text-body">Your dashboard and services will be tailored to this.</p>

      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        {USER_TYPES.map(t => (
          <button
            key={t.id}
            onClick={() => choose(t.id)}
            className="focus-ring group flex items-center justify-between rounded-xl2 border border-line bg-white p-5 text-left transition-colors hover:border-royal/40"
          >
            <span>
              <span className="block font-bold text-navy">{t.label}</span>
              <span className="mt-0.5 block text-sm text-muted">{t.blurb}</span>
            </span>
            <span className="text-royal opacity-0 transition-opacity group-hover:opacity-100">→</span>
          </button>
        ))}
      </div>
    </div>
  )
}
