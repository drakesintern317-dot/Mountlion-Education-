import React from 'react'
import { Link as RouterLink } from 'react-router-dom'
import Button from '../../components/Button.jsx'

export default function GetStarted() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 md:px-8 md:py-24">
      <p className="text-xs font-semibold uppercase tracking-wide text-teal">Get started</p>
      <h1 className="mt-2 text-3xl font-extrabold text-navy md:text-4xl">How would you like to use Mountlion?</h1>
      <p className="mt-3 text-body">You can change this later — pick whichever fits what you need right now.</p>

      <div className="mt-10 grid gap-4 md:grid-cols-2">
        <OptionCard to="/create-account" title="Create a personal account" desc="For students, parents, teachers, and general users exploring services." icon="person" />
        <OptionCard to="/create-institution" title="Create an institution" desc="Set up a workspace for a school, college, university, or training centre." icon="building" />
      </div>

      <div className="mt-8 flex items-center gap-2 text-sm text-muted">
        Already have an account?
        <Button to="/sign-in" variant="ghost" className="!px-2">Sign in instead</Button>
      </div>
    </div>
  )
}

function OptionCard({ to, title, desc, icon }) {
  return (
    <RouterLink to={to} className="group focus-ring block rounded-xl2 border border-line bg-white p-6 transition-colors hover:border-royal/40">
      <span className="grid h-11 w-11 place-items-center rounded-2xl bg-royal/10 text-royal">
        {icon === 'person' ? (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.4" stroke="currentColor" strokeWidth="1.8"/><path d="M5 20c1.2-3.8 4-5.5 7-5.5s5.8 1.7 7 5.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
        ) : (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M4 21V6l8-3 8 3v15" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><path d="M9 21v-6h6v6" stroke="currentColor" strokeWidth="1.8"/></svg>
        )}
      </span>
      <h3 className="mt-4 text-lg font-bold text-navy">{title}</h3>
      <p className="mt-1 text-sm text-body">{desc}</p>
      <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-royal">Continue <span className="transition-transform group-hover:translate-x-0.5">→</span></span>
    </RouterLink>
  )
}
