import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Button from '../../components/Button.jsx'

export default function CreateAccount() {
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '' })

  function handleSubmit(e) {
    e.preventDefault()
    sessionStorage.setItem('mountlion_pending_name', form.name)
    navigate('/select-user-type')
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16 md:py-24">
      <Steps current={1} />
      <p className="mt-6 text-xs font-semibold uppercase tracking-wide text-teal">Step 1 of 2</p>
      <h1 className="mt-2 text-3xl font-extrabold text-navy">Create your account</h1>
      <p className="mt-2 text-sm text-body">This is a working prototype \u2014 no real data is sent anywhere.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <Field label="Full name" value={form.name} onChange={v => setForm({ ...form, name: v })} placeholder="Daniel Mwangi" required />
        <Field label="Email address" type="email" value={form.email} onChange={v => setForm({ ...form, email: v })} placeholder="you@example.com" required />
        <Field label="Password" type="password" value={form.password} onChange={v => setForm({ ...form, password: v })} placeholder="Create a password" required />
        <Button type="submit" className="w-full">Continue</Button>
      </form>
    </div>
  )
}

function Field({ label, type = 'text', value, onChange, placeholder, required }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-navy">{label}</span>
      <input
        type={type}
        required={required}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="focus-ring w-full rounded-xl border border-line px-4 py-2.5 text-sm text-navy placeholder:text-muted"
      />
    </label>
  )
}

export function Steps({ current }) {
  return (
    <div className="flex items-center gap-2">
      {[1, 2].map(n => (
        <React.Fragment key={n}>
          <span className={`grid h-7 w-7 place-items-center rounded-full text-xs font-bold ${n <= current ? 'bg-royal text-white' : 'bg-line text-muted'}`}>{n}</span>
          {n < 2 && <span className={`h-0.5 w-8 ${n < current ? 'bg-royal' : 'bg-line'}`} />}
        </React.Fragment>
      ))}
    </div>
  )
}
