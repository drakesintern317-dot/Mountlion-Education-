import React, { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import CountrySelector from '../components/CountrySelector.jsx'

export default function Settings() {
  const { user } = useApp()
  const [tab, setTab] = useState('profile')

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 md:px-8">
      <h1 className="text-2xl font-extrabold text-navy">Settings</h1>
      <div className="mt-6 flex gap-2 border-b border-line">
        {['profile', 'notifications', 'region'].map(t => (
          <button key={t} onClick={() => setTab(t)} className={`focus-ring -mb-px border-b-2 px-4 py-2.5 text-sm font-semibold capitalize ${tab === t ? 'border-royal text-royal' : 'border-transparent text-muted hover:text-navy'}`}>
            {t}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {tab === 'profile' && (
          <div className="rounded-xl2 border border-line bg-white p-6">
            {user ? (
              <>
                <p className="text-sm text-muted">Signed in as</p>
                <p className="mt-1 text-lg font-bold text-navy">{user.name}</p>
                <p className="text-sm capitalize text-body">{user.userType}</p>
              </>
            ) : (
              <p className="text-sm text-muted">Sign in to manage your profile.</p>
            )}
          </div>
        )}
        {tab === 'notifications' && (
          <div className="space-y-3 rounded-xl2 border border-line bg-white p-6">
            {['Email notifications', 'SMS alerts', 'Push notifications'].map(n => <Toggle key={n} label={n} />)}
          </div>
        )}
        {tab === 'region' && (
          <div className="rounded-xl2 border border-line bg-white p-6">
            <p className="text-sm font-medium text-navy">Country</p>
            <div className="mt-2"><CountrySelector /></div>
          </div>
        )}
      </div>
    </div>
  )
}

function Toggle({ label }) {
  const [on, setOn] = useState(true)
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-navy">{label}</span>
      <button onClick={() => setOn(!on)} className={`focus-ring h-6 w-11 rounded-full transition-colors ${on ? 'bg-royal' : 'bg-line'}`}>
        <span className={`block h-5 w-5 translate-x-0.5 rounded-full bg-white transition-transform ${on ? 'translate-x-5' : ''}`} />
      </button>
    </div>
  )
}
