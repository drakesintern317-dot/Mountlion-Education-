// Deterministic-ish mock data layer.
// Swap these functions for real API calls once a backend is connected —
// nothing in the pages talks to this file's internals directly except through these exports.

export function statsForInstitution(institutionType) {
  const base = {
    primary: { people: 612, staff: 28, attendance: 94, revenue: 'KES 1.2M', label: 'Pupils' },
    junior: { people: 480, staff: 24, attendance: 92, revenue: 'KES 980K', label: 'Learners' },
    high: { people: 1140, staff: 61, attendance: 91, revenue: 'KES 3.4M', label: 'Students' },
    college: { people: 2380, staff: 140, attendance: 88, revenue: 'KES 9.1M', label: 'Students' },
    tvet: { people: 860, staff: 52, attendance: 90, revenue: 'KES 2.6M', label: 'Trainees' },
    university: { people: 14200, staff: 890, attendance: 86, revenue: 'KES 61M', label: 'Students' },
    training: { people: 340, staff: 18, attendance: 93, revenue: 'KES 740K', label: 'Learners' },
  }
  return base[institutionType] || base.high
}

export function tasksForUser(userType) {
  const common = [
    { id: 't1', title: 'Review 3 pending fee payments', done: false },
    { id: 't2', title: 'Respond to a message in Mountlion Connect', done: false },
    { id: 't3', title: 'Confirm attendance for today', done: false },
  ]
  const byType = {
    student: [
      { id: 's1', title: 'Submit Biology CAT 2', done: false },
      { id: 's2', title: 'Scholarship application closes in 3 days', done: false },
      { id: 's3', title: 'Pick electives for next term', done: false },
    ],
    parent: [
      { id: 'p1', title: 'Approve school trip permission slip', done: false },
      { id: 'p2', title: 'Term 2 fee balance due', done: false },
      { id: 'p3', title: 'Parent-teacher meeting on Friday', done: false },
    ],
    teacher: [
      { id: 'te1', title: 'Grade Form 2 English essays', done: false },
      { id: 'te2', title: 'Submit weekly lesson plan', done: false },
      { id: 'te3', title: '4 students flagged for low attendance', done: false },
    ],
    admin: [
      { id: 'a1', title: 'Approve 2 staff leave requests', done: false },
      { id: 'a2', title: 'Review this term\u2019s compliance filing', done: false },
      { id: 'a3', title: 'Payroll run scheduled for Friday', done: false },
    ],
  }
  return byType[userType] || common
}

export function notificationsMock() {
  return [
    { id: 'n1', title: 'New message in Mountlion Connect', time: '5m ago', read: false },
    { id: 'n2', title: 'Fee statement generated', time: '1h ago', read: false },
    { id: 'n3', title: 'Assessment results published', time: 'Yesterday', read: true },
    { id: 'n4', title: 'System maintenance scheduled Sunday 2am', time: '2 days ago', read: true },
  ]
}

export function activityMock() {
  return [
    { id: 'ac1', text: 'Grade 7B attendance marked', time: '08:12' },
    { id: 'ac2', text: 'New scholarship listed: Wings to Fly', time: '07:50' },
    { id: 'ac3', text: 'Fee payment received \u2014 KES 12,000', time: '07:31' },
    { id: 'ac4', text: '3 new applications received', time: 'Yesterday' },
  ]
}

export function conversationsMock() {
  return [
    { id: 'c1', name: 'Staff Room', preview: 'Meeting moved to 3pm', unread: 2, group: true,
      messages: [
        { from: 'them', text: 'Reminder: staff meeting moved to 3pm today.' },
        { from: 'them', text: 'Bring your term reports please.' },
      ] },
    { id: 'c2', name: 'Grace Wanjiru', preview: 'Thank you, received!', unread: 0, group: false,
      messages: [
        { from: 'me', text: 'I\u2019ve sent the fee statement to your email.' },
        { from: 'them', text: 'Thank you, received!' },
      ] },
    { id: 'c3', name: 'Form 3 Announcements', preview: 'CAT timetable is out', unread: 5, group: true,
      messages: [
        { from: 'them', text: 'The CAT 2 timetable has been posted on the noticeboard.' },
      ] },
    { id: 'c4', name: 'David Otieno', preview: 'Can we reschedule?', unread: 1, group: false,
      messages: [
        { from: 'them', text: 'Can we reschedule tomorrow\u2019s meeting to Thursday?' },
      ] },
  ]
}

export const AI_PROMPTS = [
  'What needs my attention today?',
  'Analyze this performance data.',
  'Create a staff meeting agenda.',
  'Explain this education service.',
  'Which students need attention?',
]

const AI_RESPONSES = {
  'What needs my attention today?':
    'You have 5 items today: 2 fee approvals, 1 unread Connect message, a compliance filing due Friday, and 4 students flagged for low attendance this week in Form 2B.',
  'Analyze this performance data.':
    'Average attendance is 91%, up 2 points from last term. English and Mathematics mean scores improved; Chemistry dipped slightly \u2014 likely tied to the lab equipment delay reported in week 3.',
  'Create a staff meeting agenda.':
    '1) Term 2 exam calendar. 2) Compliance filing status. 3) Staffing gap in Chemistry. 4) Parent engagement for Form 1 intake. 5) AOB.',
  'Explain this education service.':
    'Student Financing connects learners to instalment plans and employer-sponsored fee support, with eligibility checked automatically against your institution\u2019s fee structure.',
  'Which students need attention?':
    '4 students in Form 2B have attendance under 80% this month, and 2 students have an outstanding balance past the grace period. I can open the full list if you\u2019d like.',
}

export function aiRespond(prompt) {
  return AI_RESPONSES[prompt] ||
    'Here\u2019s a summary based on your current data: everything is broadly on track, with a few items worth a closer look in your dashboard.'
}

export function ownerInstitutionsMock() {
  return [
    { id: 'i1', name: 'Kericho Girls High School', type: 'High School', users: 1140, plan: 'Growth', status: 'Active' },
    { id: 'i2', name: 'Riverside Primary', type: 'Primary School', users: 612, plan: 'Starter', status: 'Active' },
    { id: 'i3', name: 'Nairobi Polytechnic', type: 'TVET', users: 860, plan: 'Growth', status: 'Trial' },
    { id: 'i4', name: 'Mount Kenya College', type: 'College', users: 2380, plan: 'Scale', status: 'Active' },
  ]
}

export function paymentDestinationsMock() {
  return [
    { id: 'pd1', type: 'M-Pesa Till', label: 'Till 774411', active: true },
    { id: 'pd2', type: 'M-Pesa Paybill', label: 'Paybill 400200', active: false },
    { id: 'pd3', type: 'Bank Account', label: 'Equity \u2022\u2022\u20226621', active: false },
  ]
}
