export const COUNTRIES = [
  { code: 'KE', name: 'Kenya', currency: 'KES' },
  { code: 'UG', name: 'Uganda', currency: 'UGX' },
  { code: 'TZ', name: 'Tanzania', currency: 'TZS' },
  { code: 'RW', name: 'Rwanda', currency: 'RWF' },
  { code: 'NG', name: 'Nigeria', currency: 'NGN' },
  { code: 'GH', name: 'Ghana', currency: 'GHS' },
  { code: 'ZA', name: 'South Africa', currency: 'ZAR' },
  { code: 'GB', name: 'United Kingdom', currency: 'GBP' },
  { code: 'US', name: 'United States', currency: 'USD' },
  { code: 'CA', name: 'Canada', currency: 'CAD' },
  { code: 'XX', name: 'Other Countries', currency: '—' },
]

export const USER_TYPES = [
  { id: 'student', label: 'Student', blurb: 'Track courses, grades, and applications.' },
  { id: 'parent', label: 'Parent / Guardian', blurb: 'Follow a child\u2019s progress and fees.' },
  { id: 'teacher', label: 'Teacher', blurb: 'Manage classes, grading, and lesson plans.' },
  { id: 'lecturer', label: 'Lecturer', blurb: 'Manage units, cohorts, and research.' },
  { id: 'trainer', label: 'Trainer', blurb: 'Deliver TVET and professional courses.' },
  { id: 'admin', label: 'Institution Administrator', blurb: 'Run operations across your institution.' },
  { id: 'general', label: 'General User', blurb: 'Explore education services and support.' },
]

export const INSTITUTION_TYPES = [
  { id: 'primary', label: 'Primary School', unit: 'Pupils', stat: 'Classes' },
  { id: 'junior', label: 'Junior Secondary', unit: 'Learners', stat: 'Streams' },
  { id: 'high', label: 'High School', unit: 'Students', stat: 'Streams' },
  { id: 'college', label: 'College', unit: 'Students', stat: 'Programmes' },
  { id: 'tvet', label: 'TVET', unit: 'Trainees', stat: 'Trades' },
  { id: 'university', label: 'University', unit: 'Students', stat: 'Faculties' },
  { id: 'training', label: 'Professional Training Institution', unit: 'Learners', stat: 'Courses' },
]

export const SERVICE_CATEGORIES = [
  {
    id: 'education',
    label: 'Education',
    blurb: 'Curriculum-aligned learning across every level.',
    featured: ['National curriculum tracker', 'Exam timetables', 'School transfer requests'],
  },
  {
    id: 'student',
    label: 'Student Services',
    blurb: 'Everything a learner needs outside the classroom.',
    featured: ['ID & records', 'Timetable builder', 'Attendance history'],
  },
  {
    id: 'scholarships',
    label: 'Scholarships',
    blurb: 'Discover and apply for funding you qualify for.',
    featured: ['Government bursaries', 'Merit scholarships', 'County bursary fund'],
  },
  {
    id: 'financing',
    label: 'Student Financing',
    blurb: 'Loans and payment plans for tuition and fees.',
    featured: ['HELB-style loans', 'Fee instalment plans', 'Employer sponsorships'],
  },
  {
    id: 'institution',
    label: 'Institution Services',
    blurb: 'Operational tools for schools and colleges.',
    featured: ['Accreditation status', 'Staff payroll', 'Compliance filings'],
  },
  {
    id: 'government',
    label: 'Government Services',
    blurb: 'Direct links into national education systems.',
    featured: ['NEMIS-style registration', 'Exam body portals', 'Teacher licensing'],
  },
  {
    id: 'learning',
    label: 'Learning',
    blurb: 'Courses, tutoring, and skills content.',
    featured: ['Micro-courses', 'Past paper library', 'Peer tutoring'],
  },
  {
    id: 'career',
    label: 'Career Services',
    blurb: 'From graduation into the working world.',
    featured: ['Internship board', 'CV & interview coaching', 'Employer partnerships'],
  },
]

export const DEMO_MODES = [
  { id: 'public', label: 'Public User' },
  { id: 'primary', label: 'Primary School' },
  { id: 'junior', label: 'Junior Secondary' },
  { id: 'high', label: 'High School' },
  { id: 'college', label: 'College' },
  { id: 'tvet', label: 'TVET' },
  { id: 'university', label: 'University' },
  { id: 'owner', label: 'Platform Owner' },
]
