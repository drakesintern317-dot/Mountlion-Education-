import React, { createContext, useContext, useState, useMemo } from 'react'
import { COUNTRIES } from '../data/reference.js'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [demoMode, setDemoMode] = useState('public')
  const [country, setCountry] = useState(COUNTRIES[0])
  const [user, setUser] = useState(null) // { name, userType }
  const [institution, setInstitution] = useState(null) // { name, type }
  const [notifOpen, setNotifOpen] = useState(false)

  function createAccount({ name, userType }) {
    setUser({ name, userType })
  }

  function createInstitution({ name, type }) {
    setInstitution({ name, type })
    setDemoMode(type)
  }

  function signOut() {
    setUser(null)
    setInstitution(null)
    setDemoMode('public')
  }

  const value = useMemo(() => ({
    demoMode, setDemoMode,
    country, setCountry,
    user, createAccount, setUser,
    institution, createInstitution, setInstitution,
    notifOpen, setNotifOpen,
    signOut,
  }), [demoMode, country, user, institution, notifOpen])

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
