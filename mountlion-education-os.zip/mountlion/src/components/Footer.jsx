import React from 'react'
import Logo from './Logo.jsx'

export default function Footer() {
  return (
    <footer className="hidden border-t border-line bg-white md:block">
      <div className="mx-auto max-w-7xl px-8 py-12">
        <div className="flex flex-wrap items-start justify-between gap-10">
          <div className="max-w-xs">
            <Logo />
            <p className="mt-3 text-sm text-muted">One intelligent platform for education, institutions, students, and education services worldwide.</p>
          </div>
          <div className="flex gap-16 text-sm">
            <div>
              <p className="font-semibold text-navy">Platform</p>
              <ul className="mt-3 space-y-2 text-muted">
                <li>Services</li><li>Institutions</li><li>Mountlion AI</li><li>Mountlion Connect</li>
              </ul>
            </div>
            <div>
              <p className="font-semibold text-navy">Company</p>
              <ul className="mt-3 space-y-2 text-muted">
                <li>About Oscarian Express</li><li>Trust & Safety</li><li>Support</li>
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-10 border-t border-line pt-6 text-xs text-muted">
          Mountlion Education OS™ is property of Oscarian Express. © 2026 Oscarian Express. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
