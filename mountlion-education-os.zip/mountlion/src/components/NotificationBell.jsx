import React, { useState } from 'react'
import { notificationsMock } from '../data/mock.js'

export default function NotificationBell() {
  const [open, setOpen] = useState(false)
  const [items, setItems] = useState(notificationsMock())
  const unread = items.filter(i => !i.read).length

  function markRead(id) {
    setItems(items.map(i => i.id === id ? { ...i, read: true } : i))
  }

  return (
    <div className="relative">
      <button
        aria-label="Notifications"
        onClick={() => setOpen(o => !o)}
        className="focus-ring relative grid h-9 w-9 place-items-center rounded-full text-navy hover:bg-navy/5"
      >
        <svg width="19" height="19" viewBox="0 0 24 24" fill="none"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M13.7 21a2 2 0 01-3.4 0" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
        {unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-royal px-1 text-[10px] font-bold text-white">{unread}</span>
        )}
      </button>
      {open && (
        <div className="absolute right-0 z-30 mt-2 w-80 rounded-2xl border border-line bg-white p-2 shadow-panel">
          <div className="flex items-center justify-between px-3 py-2">
            <p className="text-sm font-semibold text-navy">Notifications</p>
            <button onClick={() => setItems(items.map(i => ({...i, read: true})))} className="focus-ring rounded text-xs font-medium text-royal hover:underline">Mark all read</button>
          </div>
          <ul className="max-h-72 overflow-y-auto thin-scroll">
            {items.map(n => (
              <li key={n.id}>
                <button onClick={() => markRead(n.id)} className="focus-ring flex w-full items-start gap-2.5 rounded-xl px-3 py-2.5 text-left hover:bg-canvas">
                  <span className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${n.read ? 'bg-line' : 'bg-royal'}`} />
                  <span>
                    <span className={`block text-sm ${n.read ? 'text-muted' : 'text-navy font-medium'}`}>{n.title}</span>
                    <span className="block text-xs text-muted">{n.time}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
