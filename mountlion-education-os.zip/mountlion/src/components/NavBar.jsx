import React, { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import Logo from './Logo.jsx'
import Button from './Button.jsx'
import NotificationBell from './NotificationBell.jsx'
import CountrySelector from './CountrySelector.jsx'
import DemoSelector from './DemoSelector.jsx'
import { useApp } from '../context/AppContext.jsx'

const links = [
  { to: '/services', label: 'Services' },
  { to: '/institutions', label: 'Institutions' },
  { to: '/connect', label: 'Connect' },
  { to: '/ai', label: 'Mountlion AI' },
]

export default function NavBar() {
  const { user, institution, signOut, demoMode } = useApp()
  const [menuOpen, setMenuOpen] = useState(false)
  const navigate = useNavigate()
  const isOwnerDemo = demoMode === 'owner'

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-line bg-white/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:px-8">
          <div className="flex items-center gap-8">
            <Logo />
            <nav className="hidden items-center gap-6 lg:flex">
              {links.map(l => (
                <NavLink key={l.to} to={l.to} className={({isActive}) => `focus-ring rounded text-sm font-medium transition-colors ${isActive ? 'text-royal' : 'text-navy/80 hover:text-royal'}`}>
                  {l.label}
                </NavLink>
              ))}
              {isOwnerDemo && (
                <NavLink to="/owner" className={({isActive}) => `focus-ring rounded text-sm font-medium ${isActive ? 'text-royal' : 'text-navy/80 hover:text-royal'}`}>
                  Owner Center
                </NavLink>
              )}
            </nav>
          </div>

          <div className="hidden items-center gap-3 md:flex">
            <div className="hidden lg:block"><CountrySelector /></div>
            <DemoSelector />
            {user ? (
              <>
                <NotificationBell />
                <button onClick={() => navigate('/dashboard')} className="focus-ring flex items-center gap-2 rounded-full border border-line py-1 pl-1 pr-3 hover:border-royal/40">
                  <span className="grid h-7 w-7 place-items-center rounded-full bg-navy text-xs font-bold text-white">{user.name?.[0]?.toUpperCase() || 'U'}</span>
                  <span className="text-sm font-medium text-navy">{user.name?.split(' ')[0]}</span>
                </button>
                <button onClick={() => { signOut(); navigate('/') }} className="focus-ring text-sm font-medium text-muted hover:text-navy">Sign out</button>
              </>
            ) : (
              <>
                <Button to="/sign-in" variant="ghost">Sign In</Button>
                <Button to="/get-started" variant="primary">Get Started</Button>
              </>
            )}
          </div>

          <button aria-label="Open menu" onClick={() => setMenuOpen(true)} className="focus-ring grid h-9 w-9 place-items-center rounded-lg md:hidden">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M4 12h16M4 17h16" stroke="#0B1F3A" strokeWidth="2" strokeLinecap="round"/></svg>
          </button>
        </div>
      </header>

      {/* Mobile slide-out menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-navy/40" onClick={() => setMenuOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-80 max-w-[85vw] overflow-y-auto bg-white p-5 shadow-panel">
            <div className="flex items-center justify-between">
              <Logo compact />
              <button aria-label="Close menu" onClick={() => setMenuOpen(false)} className="focus-ring grid h-9 w-9 place-items-center rounded-lg">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="#0B1F3A" strokeWidth="2" strokeLinecap="round"/></svg>
              </button>
            </div>

            {user && (
              <div className="mt-5 flex items-center gap-3 rounded-2xl bg-canvas p-3">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-navy text-sm font-bold text-white">{user.name?.[0]?.toUpperCase() || 'U'}</span>
                <div>
                  <p className="text-sm font-semibold text-navy">{user.name}</p>
                  <p className="text-xs text-muted capitalize">{user.userType}</p>
                </div>
              </div>
            )}

            <nav className="mt-6 flex flex-col gap-1">
              {links.map(l => (
                <Link key={l.to} to={l.to} onClick={() => setMenuOpen(false)} className="focus-ring rounded-xl px-3 py-3 text-sm font-medium text-navy hover:bg-canvas">{l.label}</Link>
              ))}
              {user && <Link to="/dashboard" onClick={() => setMenuOpen(false)} className="focus-ring rounded-xl px-3 py-3 text-sm font-medium text-navy hover:bg-canvas">Dashboard</Link>}
              {isOwnerDemo && <Link to="/owner" onClick={() => setMenuOpen(false)} className="focus-ring rounded-xl px-3 py-3 text-sm font-medium text-navy hover:bg-canvas">Owner Center</Link>}
              <Link to="/settings" onClick={() => setMenuOpen(false)} className="focus-ring rounded-xl px-3 py-3 text-sm font-medium text-navy hover:bg-canvas">Settings</Link>
            </nav>

            <div className="mt-6 flex items-center gap-2">
              <CountrySelector />
              <DemoSelector />
            </div>

            <div className="mt-6 flex flex-col gap-2">
              {user ? (
                <Button variant="secondary" onClick={() => { signOut(); setMenuOpen(false); navigate('/') }}>Sign out</Button>
              ) : (
                <>
                  <Button to="/get-started" onClick={() => setMenuOpen(false)}>Get Started</Button>
                  <Button to="/sign-in" variant="secondary" onClick={() => setMenuOpen(false)}>Sign In</Button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}
