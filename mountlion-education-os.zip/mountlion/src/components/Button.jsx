import React from 'react'
import { Link } from 'react-router-dom'

const variants = {
  primary: 'bg-royal text-white hover:bg-[#1150cf] shadow-sm',
  secondary: 'bg-white text-navy border border-line hover:border-royal/40 hover:text-royal',
  ghost: 'text-navy hover:bg-navy/5',
  teal: 'bg-teal text-white hover:bg-[#0b8580]',
}

export default function Button({ to, href, onClick, variant = 'primary', className = '', children, type = 'button', ...rest }) {
  const classes = `focus-ring inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-colors duration-150 disabled:opacity-50 ${variants[variant]} ${className}`
  if (to) return <Link to={to} className={classes} {...rest}>{children}</Link>
  if (href) return <a href={href} className={classes} {...rest}>{children}</a>
  return <button type={type} onClick={onClick} className={classes} {...rest}>{children}</button>
}
