import React, { useState } from 'react'
import { DEMO_MODES } from '../data/reference.js'
import { useApp } from '../context/AppContext.jsx'

export default function DemoSelector() {
  const { demoMode, setDemoMode } = useApp()
  const [open, setOpen] = useState(false)
  const current = DEMO_MODES.find(d => d.id === demoMode)

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="focus-ring flex items-center gap-1.5 rounded-full bg-teal/10 px-3 py-1.5 text-xs font-semibold text-teal hover:bg-teal/15"
      >
        <span className="h-1.5 w-1.5 rounded-full bg-teal" />
        Demo: {current?.label}
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </button>
      {open && (
        <div className="absolute right-0 z-30 mt-2 w-64 rounded-2xl border border-line bg-white p-1.5 shadow-panel">
          <p className="px-3 pt-1.5 pb-1 text-xs font-semibold uppercase tracking-wide text-muted">Switch demo view</p>
          {DEMO_MODES.map(d => (
            <button
              key={d.id}
              onClick={() => { setDemoMode(d.id); setOpen(false) }}
              className={`focus-ring block w-full rounded-xl px-3 py-2 text-left text-sm hover:bg-canvas ${d.id === demoMode ? 'bg-teal/10 font-semibold text-teal' : 'text-navy'}`}
            >
              {d.label}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
