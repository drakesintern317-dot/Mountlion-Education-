import React, { useEffect, useState } from 'react'

function useTicker(base, variance, intervalMs) {
  const [val, setVal] = useState(base)
  useEffect(() => {
    const id = setInterval(() => {
      setVal(v => Math.max(0, v + Math.round((Math.random() - 0.45) * variance)))
    }, intervalMs)
    return () => clearInterval(id)
  }, [])
  return val
}

export default function LivePreviewPanel() {
  const active = useTicker(2481, 6, 2200)
  const applications = useTicker(146, 3, 3000)
  const attendance = useTicker(91, 1, 4000)

  return (
    <div className="relative">
      <div className="absolute -inset-4 -z-10 rounded-[2rem] bg-gradient-to-br from-royal/10 via-teal/10 to-transparent blur-2xl" aria-hidden="true" />
      <div className="rounded-xl2 border border-line bg-white p-5 shadow-panel">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-teal animate-pulse" />
            <span className="text-xs font-semibold uppercase tracking-wide text-muted">Live platform activity</span>
          </div>
          <span className="rounded-full bg-navy/5 px-2.5 py-1 text-[10px] font-semibold text-navy">Demo data</span>
        </div>

        <div className="mt-5 grid grid-cols-3 gap-3">
          <div className="rounded-2xl bg-canvas p-3.5">
            <p className="font-mono text-2xl font-medium text-navy tabular-nums">{active.toLocaleString()}</p>
            <p className="mt-1 text-xs text-muted">Active learners now</p>
          </div>
          <div className="rounded-2xl bg-canvas p-3.5">
            <p className="font-mono text-2xl font-medium text-teal tabular-nums">{applications}</p>
            <p className="mt-1 text-xs text-muted">Applications today</p>
          </div>
          <div className="rounded-2xl bg-canvas p-3.5">
            <p className="font-mono text-2xl font-medium text-royal tabular-nums">{attendance}%</p>
            <p className="mt-1 text-xs text-muted">Attendance avg.</p>
          </div>
        </div>

        <div className="mt-4 space-y-2.5 rounded-2xl border border-line p-3.5">
          <p className="text-xs font-semibold text-navy">Ask Mountlion AI</p>
          <div className="flex items-center gap-2 rounded-full bg-canvas px-3 py-2">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" className="text-teal shrink-0"><path d="M12 2l1.8 4.6L18 8l-4.2 1.4L12 14l-1.8-4.6L6 8l4.2-1.4L12 2z" fill="currentColor"/></svg>
            <p className="truncate text-xs text-muted">"Which students need attention this week?"</p>
          </div>
        </div>
      </div>
    </div>
  )
}
