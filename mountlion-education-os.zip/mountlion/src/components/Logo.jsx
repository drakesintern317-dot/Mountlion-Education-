import React from 'react'
import { Link } from 'react-router-dom'

export default function Logo({ compact = false }) {
  return (
    <Link to="/" className="flex items-center gap-2.5 focus-ring rounded-lg">
      <svg width="30" height="30" viewBox="0 0 32 32" fill="none" aria-hidden="true">
        <path d="M4 24L12 6L16 15L20 6L28 24" stroke="#155EEF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M4 24L12 6L16 15" stroke="#0E9F9A" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      {!compact && (
        <span className="font-display font-extrabold text-[1.05rem] tracking-tight text-navy">
          Mountlion <span className="font-semibold text-royal">Education OS</span>
          <sup className="text-[0.55rem] ml-0.5 text-muted">™</sup>
        </span>
      )}
    </Link>
  )
}
