import React from 'react'
import { NavLink } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'

const icons = {
  home: <path d="M4 11l8-7 8 7v9a1 1 0 01-1 1h-4v-6H9v6H5a1 1 0 01-1-1v-9z" />,
  dashboard: <path d="M4 4h7v7H4V4zm9 0h7v4h-7V4zm0 7h7v9h-7v-9zM4 14h7v6H4v-6z" />,
  connect: <path d="M21 12a8 8 0 10-3.5 6.6L21 20l-1.2-3.4A7.96 7.96 0 0021 12z" />,
  ai: <path d="M12 2l1.8 4.6L18 8l-4.2 1.4L12 14l-1.8-4.6L6 8l4.2-1.4L12 2z" />,
}

export default function BottomNav() {
  const { user } = useApp()
  const items = [
    { to: '/', label: 'Home', icon: 'home' },
    { to: user ? '/dashboard' : '/services', label: user ? 'Dashboard' : 'Services', icon: 'dashboard' },
    { to: '/connect', label: 'Connect', icon: 'connect' },
    { to: '/ai', label: 'Mountlion AI', icon: 'ai' },
  ]
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-white/95 backdrop-blur pb-[env(safe-area-inset-bottom)] md:hidden">
      <ul className="grid grid-cols-4">
        {items.map(it => (
          <li key={it.to}>
            <NavLink to={it.to} className={({isActive}) => `focus-ring flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium ${isActive ? 'text-royal' : 'text-muted'}`}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">{icons[it.icon]}</svg>
              {it.label}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  )
}
