import React, { useState } from 'react'
import { COUNTRIES } from '../data/reference.js'
import { useApp } from '../context/AppContext.jsx'

export default function CountrySelector({ compact = false }) {
  const { country, setCountry } = useApp()
  const [open, setOpen] = useState(false)

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="focus-ring flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-xs font-medium text-navy hover:border-royal/40"
      >
        <span>{country.name}</span>
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </button>
      {open && (
        <div className="absolute right-0 z-30 mt-2 max-h-72 w-56 overflow-y-auto thin-scroll rounded-2xl border border-line bg-white p-1.5 shadow-panel">
          {COUNTRIES.map(c => (
            <button
              key={c.code}
              onClick={() => { setCountry(c); setOpen(false) }}
              className={`focus-ring flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-sm hover:bg-canvas ${c.code === country.code ? 'text-royal font-semibold' : 'text-navy'}`}
            >
              <span>{c.name}</span>
              <span className="text-xs text-muted">{c.currency}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
